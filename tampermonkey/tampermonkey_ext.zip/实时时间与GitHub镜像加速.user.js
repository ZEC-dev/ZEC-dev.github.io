// ==UserScript==
// @name         实时时间与GitHub镜像加速
// @namespace    https://ZEC-dev.github.io
// @version      1.2.0
// @description  显示实时时间，并通过镜像站加速GitHub访问及下载
// @author       ZEC-dev
// @homepage     https://ZEC-dev.github.io
// @icon         https://ZEC-dev.github.io/img/ico.ico
// @license      MIT
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 记录网页打开时间
    const pageLoadTime = new Date();

    // 配置部分：可用的镜像站列表
    const availableMirrors = [
        {
            name: 'BGitHub',
            raw: 'raw.bgithub.xyz',
            main: 'bgithub.xyz',
            gist: 'gist.bgithub.xyz',
            enabled: true
        }
        // 你可以在这里继续添加其他镜像站
        // {
        //     name: 'KGitHub',
        //     raw: 'raw.kkgithub.com',
        //     main: 'kkgithub.com',
        //     gist: 'gist.kkgithub.com',
        //     enabled: false
        // }
    ];

    // 创建信息显示框
    function createInfoBox() {
        const infobox = document.createElement('div');
        infobox.id = 'time-info-box';

        Object.assign(infobox.style, {
            position: 'fixed',
            top: '10px',
            right: '10px',
            background: 'rgba(40, 44, 52, 0.95)',
            color: '#61dafb',
            padding: '12px 18px',
            borderRadius: '25px',
            fontFamily: 'Monaco, Consolas, monospace',
            fontSize: '12px',
            fontWeight: 'bold',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
            zIndex: '10000',
            border: '1px solid rgba(97, 218, 251, 0.3)',
            maxWidth: '280px',
            textAlign: 'center',
            lineHeight: '1.4',
            transition: 'all 0.3s ease',
            backdropFilter: 'blur(15px)',
            WebkitBackdropFilter: 'blur(15px)',
            cursor: 'move',
            userSelect: 'none',
            opacity: '0',
            transform: 'translateX(100px)'
        });

        // 拖动功能变量
        let isDragging = false;
        let startX, startY, initialX, initialY;

        // 计算网页打开时长
        function getPageOpenTime() {
            const now = new Date();
            const diff = now - pageLoadTime;

            const hours = Math.floor(diff / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diff % (1000 * 60)) / 1000);

            if (hours > 0) {
                return `${hours}时${minutes}分${seconds}秒`;
            } else if (minutes > 0) {
                return `${minutes}分${seconds}秒`;
            } else {
                return `${seconds}秒`;
            }
        }

        // 获取当前GitHub状态
        function getGitHubStatus() {
            if (isGitHubPage()) {
                const mirror = getCurrentMirror();
                return `🚀 GitHub加速: ${mirror.name}`;
            }
            return '🌐 普通网页';
        }

        // 更新内容函数
        function update() {
            const now = new Date();
            const time = now.toLocaleTimeString();
            const date = now.toLocaleDateString();
            const openTime = getPageOpenTime();
            const githubStatus = getGitHubStatus();

            infobox.innerHTML = `
                <div style="margin-bottom: 5px;">🕒 当前时间: ${time}</div>
                <div style="margin-bottom: 5px;">📅 当前日期: ${date}</div>
                <div style="margin-bottom: 5px;">⏱️ 网页打开: ${openTime}</div>
                <div style="margin-bottom: 5px;">${githubStatus}</div>
                <div style="font-size: 10px; opacity: 0.7;">拖动移动 | 双击关闭</div>
            `;
        }

        // 拖动功能实现
        function startDrag(e) {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;

            const rect = infobox.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;

            infobox.style.cursor = 'grabbing';
            infobox.style.opacity = '0.8';

            document.addEventListener('mousemove', onDrag);
            document.addEventListener('mouseup', stopDrag);

            e.preventDefault();
        }

        function onDrag(e) {
            if (!isDragging) return;

            const dx = e.clientX - startX;
            const dy = e.clientY - startY;

            infobox.style.right = 'auto';
            infobox.style.left = (initialX + dx) + 'px';
            infobox.style.top = (initialY + dy) + 'px';
        }

        function stopDrag() {
            isDragging = false;
            infobox.style.cursor = 'move';
            infobox.style.opacity = '1';

            document.removeEventListener('mousemove', onDrag);
            document.removeEventListener('mouseup', stopDrag);
        }

        // 双击关闭功能
        function handleDoubleClick() {
            infobox.style.transition = 'all 0.5s ease';
            infobox.style.opacity = '0';
            infobox.style.transform = 'scale(0.8)';
            setTimeout(() => {
                if (infobox.parentNode) {
                    infobox.parentNode.removeChild(infobox);
                }
            }, 500);
        }

        // 绑定事件
        infobox.addEventListener('mousedown', startDrag);
        infobox.addEventListener('dblclick', handleDoubleClick);

        // 初始化和定时更新
        update();
        setInterval(update, 1000);
        document.body.appendChild(infobox);

        // 入场动画
        setTimeout(() => {
            infobox.style.opacity = '1';
            infobox.style.transform = 'translateX(0)';
        }, 100);

        return infobox;
    }

    // GitHub镜像加速功能
    function setupGitHubAcceleration() {
        if (!isGitHubPage()) return;

        const currentMirror = getCurrentMirror();
        if (!currentMirror) return;

        console.log(`🎯 使用GitHub镜像: ${currentMirror.name}`);

        // 替换页面中的GitHub链接
        replaceGitHubLinks(currentMirror);

        // 处理动态加载的内容
        setupDynamicContentHandler(currentMirror);

        // 添加下载链接加速
        accelerateDownloadLinks(currentMirror);
    }

    // 检查是否在GitHub相关页面
    function isGitHubPage() {
        return location.hostname.includes('github.com') ||
               location.hostname.includes('raw.githubusercontent.com') ||
               location.hostname.includes('gist.github.com');
    }

    // 获取当前启用的镜像
    function getCurrentMirror() {
        return availableMirrors.find(mirror => mirror.enabled) || availableMirrors[0];
    }

    // 替换页面中的GitHub链接
    function replaceGitHubLinks(mirror) {
        const domainMap = {
            'github.com': mirror.main,
            'raw.githubusercontent.com': mirror.raw,
            'gist.github.com': mirror.gist
        };

        replaceLinksInDocument(domainMap);
    }

    // 在文档中替换链接
    function replaceLinksInDocument(domainMap) {
        const elements = [
            ...document.querySelectorAll('a[href]'),
            ...document.querySelectorAll('link[href]'),
            ...document.querySelectorAll('script[src]'),
            ...document.querySelectorAll('img[src]')
        ];

        elements.forEach(element => {
            let url = element.href || element.src;
            if (!url) return;

            for (let original in domainMap) {
                if (url.includes(original)) {
                    const newUrl = url.replace(original, domainMap[original]);

                    if (element.href) {
                        element.href = newUrl;
                    } else if (element.src) {
                        element.src = newUrl;
                    }

                    // 添加视觉提示
                    if (element.tagName === 'A') {
                        element.style.borderBottom = '1px dashed #4CAF50';
                        element.title = `已加速到 ${domainMap[original]}`;
                    }
                    break;
                }
            }
        });
    }

    // 设置动态内容处理器
    function setupDynamicContentHandler(mirror) {
        const observer = new MutationObserver(function(mutations) {
            let shouldUpdate = false;

            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length > 0) {
                    shouldUpdate = true;
                }
            });

            if (shouldUpdate) {
                setTimeout(() => {
                    replaceGitHubLinks(mirror);
                    accelerateDownloadLinks(mirror);
                }, 100);
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // 加速下载链接
    function accelerateDownloadLinks(mirror) {
        // 处理代码下载链接
        const downloadLinks = document.querySelectorAll([
            'a[href*="/archive/"]',
            'a[href*="/releases/download/"]',
            'a[href*="/raw/"]',
            'a[download]'
        ].join(','));

        downloadLinks.forEach(link => {
            let href = link.href;
            if (href && href.includes('github.com')) {
                link.href = href.replace('github.com', mirror.main);
                link.style.border = '1px solid #4CAF50';
                link.style.padding = '2px 5px';
                link.style.borderRadius = '3px';
                link.title = '下载已加速';
            }
        });

        // 处理代码仓库克隆链接
        const cloneLinks = document.querySelectorAll([
            'input[value*="git@github.com"]',
            'input[value*="https://github.com"]'
        ].join(','));

        cloneLinks.forEach(input => {
            let value = input.value;
            if (value && value.includes('github.com')) {
                input.value = value.replace('github.com', mirror.main);
                input.title = '克隆地址已加速';
            }
        });
    }

    // 添加样式
    function addStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .github-accelerated {
                position: relative;
            }
            .github-accelerated::after {
                content: "🚀";
                position: absolute;
                right: 5px;
                top: 50%;
                transform: translateY(-50%);
                font-size: 12px;
            }
            [data-github-mirror] {
                border-left: 3px solid #4CAF50 !important;
                padding-left: 5px !important;
            }
        `;
        document.head.appendChild(style);
    }

    // 显示状态通知
    function showStatusNotification() {
        if (isGitHubPage()) {
            const mirror = getCurrentMirror();
            if (mirror) {
                console.log(`✅ GitHub镜像加速已启用: ${mirror.name}`);

                // 在页面顶部添加一个小提示
                const notification = document.createElement('div');
                notification.innerHTML = `🎯 正在使用 ${mirror.name} 镜像加速 GitHub 访问`;
                Object.assign(notification.style, {
                    position: 'fixed',
                    top: '0',
                    left: '0',
                    right: '0',
                    background: 'linear-gradient(90deg, #4CAF50, #45a049)',
                    color: 'white',
                    padding: '8px',
                    textAlign: 'center',
                    fontSize: '12px',
                    fontWeight: 'bold',
                    zIndex: '9999',
                    fontFamily: 'Arial, sans-serif'
                });

                document.body.appendChild(notification);

                // 3秒后自动隐藏
                setTimeout(() => {
                    notification.style.opacity = '0';
                    notification.style.transition = 'opacity 0.5s ease';
                    setTimeout(() => {
                        if (notification.parentNode) {
                            notification.parentNode.removeChild(notification);
                        }
                    }, 500);
                }, 3000);
            }
        }
    }

    // 主初始化函数
    function init() {
        // 添加样式
        addStyles();

        // 创建时间信息框
        createInfoBox();

        // 设置GitHub加速
        setupGitHubAcceleration();

        // 显示状态通知
        setTimeout(showStatusNotification, 1000);
    }

    // 启动脚本
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // 监听URL变化（用于单页面应用）
    let lastUrl = location.href;
    new MutationObserver(() => {
        const url = location.href;
        if (url !== lastUrl) {
            lastUrl = url;
            setTimeout(() => {
                if (isGitHubPage()) {
                    setupGitHubAcceleration();
                }
            }, 500);
        }
    }).observe(document, { subtree: true, childList: true });

})();
// ==UserScript==
// @name         洛谷保存站自动跳转
// @namespace    https://www.tampermonkey.net/
// @version      1.6
// @description  luogu.com 和洛谷讨论区部分帖子被封印了，此脚本可自动跳转至相应保存站，产品链接 https://www.luogu.com.cn/article/h1qvkk68。由于洛谷专栏公开可见需要审核，无法访问时请使用备用链接 https://www.cnblogs.com/oierlinch/p/18717023/luogu-jump-plugin 或 https://www.luogu.me/article/h1qvkk68。
// @author       linch & Vitamin_B
// @homepage     https://www.luogu.com.cn/user/737242
// @match        *://*.luogu.com/*
// @match        *://*.luogu.com.cn/*
// @run-at       document-end
// @license      GNU GPLv3
// @icon         https://cdn.luogu.com.cn/upload/image_hosting/u8fj7st9.png
// @downloadURL https://update.greasyfork.org/scripts/541091/%E6%B4%9B%E8%B0%B7%E4%BF%9D%E5%AD%98%E7%AB%99%E8%87%AA%E5%8A%A8%E8%B7%B3%E8%BD%AC.user.js
// @updateURL https://update.greasyfork.org/scripts/541091/%E6%B4%9B%E8%B0%B7%E4%BF%9D%E5%AD%98%E7%AB%99%E8%87%AA%E5%8A%A8%E8%B7%B3%E8%BD%AC.meta.js
// ==/UserScript==

// Copyright (c) 2025 linch Vitamin_B

(function() {
    'use strict';
    function work(){
        let a = document.URL;
        let t = document.documentElement.outerHTML;
        let b = "https://lglg.top/";
        let c=-1;
        let f = document.title;
        //帖子跳转 by linch
        for (let i = 0; i < a.length; i++) {
            if (i < a.length - 8 && a[i] == 'd' && a[i + 1] == 'i' && a[i + 2] == 's' && a[i + 3] == 'c' && a[i + 4] == 'u' && a[i + 5] == 's' && a[i + 6] == 's' && a[i+7]!='?') {
                c=i+8;
                break;
            }
        }
        if(c!=-1){
            if(t.indexOf("You are unable to access</span> luogu.com</h2>")>=0){
                b = "https://www.luogu.com.cn/discuss/";
                for(let i=c;i<a.length;i++){
                    b+=a[i];
                }
                console.log("即将跳转至洛谷中国站");
                window.location.replace(b);
            }
            if(t.indexOf("该内容已删除")>=0 || t.indexOf("题目讨论版需要有提交才能查看")>=0 || t.indexOf("请先登录")>=0){
                for(let i=c;i<a.length;i++){
                    b+=a[i];
                }
                console.log("即将跳转至帖子保存站");
                window.location.replace(b);
            }
        }
        else{
            //云剪切板/专栏跳转 其中部分代码 by Vitamin_B, linch 进行优化升级。
            b = "";
            for (let i = 0; i < a.length; i++) {
                if (i < a.length - 4 && a[i] == '.' && a[i + 1] == 'c' && a[i + 2] == 'o' && a[i + 3] == 'm') {
                    b += ".me";
                    i += 3;
                }
                else b+=a[i];
            }
            if(f.indexOf("cannot serve content")>=0 && (a.indexOf("article")>=0 || a.indexOf("paste")>=0)){
                console.log("即将跳转至云剪切板和专栏保存站");
                window.location.replace(b);
            }
            else if(f.indexOf("安全访问中心 - 洛谷")>=0){
                b="";
                console.log("即将跳转至洛谷国际站以跳转至云剪切板和专栏保存站");
                for (let i = 0; i < a.length; i++) {
                    if(i < a.length - 3 && a[i] == '.' && a[i + 1] == 'c' && a[i + 2] == 'n'){
                        i+=2;
                    }
                    else{
                        b+=a[i];
                    }
                }
                window.location.replace(b);
            }
        }
    }
    work();
    setInterval(work,1000);//判断间隔，可自行调整。
})();
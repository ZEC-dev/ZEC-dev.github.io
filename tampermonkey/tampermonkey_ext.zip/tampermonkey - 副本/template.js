// ==UserScript==
// @name         油猴脚本名称
// @namespace    你的命名空间
// @version      1.0.0
// @description  脚本功能描述
// @author       作者名称
// @homepage     主页地址
// @icon         图标URL或base64
// @license      MIT

// @match        http://*/*
// @match        https://*/*
// @include      包含的网址
// @exclude      排除的网址

// @run-at       document-end        // 指定脚本在页面加载完成时执行
// @grant        GM_getValue         // 从油猴存储中读取数据
// @grant        GM_setValue         // 将数据保存到油猴存储中
// @grant        GM_deleteValue      // 从油猴存储中删除数据
// @grant        GM_listValues       // 列出油猴存储中的所有键名
// @grant        GM_addValueChangeListener   // 监听存储值的变化
// @grant        GM_removeValueChangeListener // 移除存储值变化监听器
// @grant        GM_xmlhttpRequest   // 发送跨域HTTP请求
// @grant        GM_setClipboard     // 将数据复制到剪贴板
// @grant        GM_log              // 在控制台输出日志
// @grant        GM_info             // 获取脚本和油猴的信息
// @grant        GM_addStyle         // 向页面添加CSS样式
// @grant        GM_getResourceText  // 获取预加载资源的文本内容
// @grant        GM_getResourceURL   // 获取预加载资源的URL
// @grant        GM_notification     // 显示桌面通知
// @grant        GM_registerMenuCommand // 注册油猴菜单命令
// @grant        GM_openInTab        // 在新标签页打开链接
// @grant        unsafeWindow        // 访问原始页面的window对象
// @grant        window.close        // 关闭当前窗口
// @grant        window.focus        // 将窗口置于前台

// @require      依赖的JS库URL
// @resource     resourceName 资源URL
// @connect      允许跨域的域名
// @updateURL    脚本更新地址
// @downloadURL  脚本下载地址
// @supportURL   技术支持地址
// @contributionURL 捐赠地址
// @contributionAmount 建议捐赠金额
// ==/UserScript==

(function() {
    'use strict';
    
    // 你的代码在这里...
})();
//// license      脚本所使用的许可协议名称或地址，该协议需包含用户是否允许二次分发 
//  或修改  脚本的权利。其它人都可以随意使用时，指定为 MIT 即可。